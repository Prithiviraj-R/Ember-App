//$Id$
package Details;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
public class SignatureClass 
{
public static PublicKey pubKey=null;
public static byte[] createSign() throws NoSuchAlgorithmException, InvalidKeyException, SignatureException
{
 KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("DSA");
     
     //Initializing the key pair generator
     keyPairGen.initialize(2048);
	      
     //Generate the pair of keys
     KeyPair pair = keyPairGen.generateKeyPair();
     
     //Getting the privatekey from the key pair
     PrivateKey privKey = pair.getPrivate();
     pubKey=pair.getPublic();
     //Creating a Signature object
     Signature sign = Signature.getInstance("SHA256withDSA");

     //Initializing the signature
     sign.initSign(privKey);
     byte[] bytes = "Hello how are you".getBytes();
     
     //Adding data to the signature
     sign.update(bytes);
     
     //Calculating the signature
     byte[] signature = sign.sign();  
     
     return signature;
}

public static void readSign(byte[] signature) throws InvalidKeyException, NoSuchAlgorithmException, SignatureException 
{
	 Signature sign = Signature.getInstance("SHA256withDSA");
       
    //Initializing the signature
    sign.initVerify(pubKey);
    byte[] bytes = "Hello how are you".getBytes();
    sign.update(bytes);
    
    //Verifying the signature
    boolean bool = sign.verify(signature);
    
    if(bool) {
       System.out.println("Signature verified");   
    } else {
       System.out.println("Signature failed");
    }
}
public static void main(String[] args)
{
	 try 
	 {
		byte[] arr=createSign();
		readSign(arr);
	 } 
	 catch (InvalidKeyException | NoSuchAlgorithmException | SignatureException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
