//$Id$
package Details;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

import newexception.MistakeOccuredException;
import util.HelperUtil;
public class PropertiesFunc 
{
	public static File createFile(String path,String fileName)throws MistakeOccuredException
	{
		HelperUtil.stringCheck(path);
		HelperUtil.stringCheck(fileName);
		File testFile=new File(path,fileName);
		try
		{
		if(!testFile.exists())
		{
			testFile.createNewFile();
		}
		return testFile;
		}
		catch(IOException e)
		{
			throw new MistakeOccuredException(e);
		}
	}
	public static Properties writeFileUsingProperties(String path,
    		String fileName,boolean flag,String key,String value,Properties properties)
    		throws MistakeOccuredException
    {
        HelperUtil.objectCheck(properties);
        HelperUtil.stringCheck(key);
        HelperUtil.stringCheck(value);
    	HelperUtil.stringCheck(path);
  	    HelperUtil.stringCheck(fileName);
  	    File newFile=createFile(path,fileName);
    	FileWriter file=null;
    	BufferedWriter files=null;
    	try
    	{
    	  file=new FileWriter(newFile,flag);
    	  HelperUtil.objectCheck(file);
    	  files=new BufferedWriter(file);
    	  HelperUtil.objectCheck(files);
    	  properties.setProperty(key, value);
    	  properties.store(files,"");
    	}
    	catch(IOException e)
    	{
    	    throw new MistakeOccuredException(e);
    	}
    	finally
    	{
    		try 
    		{
    		files.close();
    		}
    		catch(Exception exp){}

    	}
		return properties;
    	
    }
	
	public static void main(String[] args)
	{
		Properties properties=new Properties();
		String path="/home/local/ZOHOCORP/prithivi-13430/IP'S";
		String fileName="ipList";
		boolean flag=true;
		String key="PKBANK";
		String value="172.24.236.64";
		try 
		{
			writeFileUsingProperties(path,
					fileName,flag,key,value,properties);
		} 
		catch (MistakeOccuredException e)
		{
			e.printStackTrace();
		}
	}
}
