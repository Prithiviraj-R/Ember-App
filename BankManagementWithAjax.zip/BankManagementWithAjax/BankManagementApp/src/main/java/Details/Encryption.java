//$Id$
package Details;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.util.Arrays;

import javax.crypto.Cipher;

import org.json.JSONArray;

public class Encryption{
   public static PrivateKey pr=null;
   public static byte[] Encryp(String toEncript)throws Exception
   {
	     Signature sign = Signature.getInstance("SHA256withRSA");
	      
	      //Creating KeyPair generator object
	      KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
	      
	      //Initializing the key pair generator
	      keyPairGen.initialize(1024);
	      
	      //Generate the pair of keys
	      KeyPair pair = keyPairGen.generateKeyPair();   
	      
	      //Getting the public key from the key pair
	      PublicKey publicKey = pair.getPublic();  
	      try(ObjectOutputStream fis=new ObjectOutputStream(new FileOutputStream("pubKey1")))
	      {
	    	  fis.writeObject(publicKey);
	      }
//	      System.out.println(publicKey);
          pr=pair.getPrivate();
	      //Creating a Cipher object
	      Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");

	      //Initializing a Cipher object
	      cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		  
	      //Adding data to the cipher
	      byte[] input = toEncript.getBytes();	  
	      cipher.update(input);
		  
	      //encrypting the data
	      byte[] cipherText = cipher.doFinal();	 
	      System.out.println(new String(cipherText, "UTF8"));
	      
//	      JSONArray arr=new JSONArray();
////	      arr[0]=cipherText;
////	      arr[1]=cipher;
////	      arr[2]=pair;
//	      arr.put(toEncript);
//	      arr.put(cipher);
//	      arr.put(pair);
//	      byte[] input = arr.toString().getBytes();	  
//	      cipher.update(input);
//		  
//	      //encrypting the data
//	      byte[] cipherText = cipher.doFinal();	 
////	      System.out.println(new String(cipherText, "UTF8"));
	      
	      return cipherText;
   }
   
   public static String decryption(byte[] er) throws Exception
   {
//	   KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
//	      
//	      //Initializing the key pair generator
//	   keyPairGen.initialize(2048);
//	      
//	   KeyPair pair = keyPairGen.generateKeyPair(); 
	   
//	   Cipher cip = (Cipher) er2;
//	   
//	   ((Cipher) er2).init(Cipher.DECRYPT_MODE, ((KeyPair) er3).getPrivate());
//	      
////	   System.out.println(((KeyPair) er3).getPrivate());
//	      //Decrypting the text
//	   byte[] decipheredText = ((Cipher) er2).doFinal((byte [])er);
//	   
//	   return new String(decipheredText);
	   PublicKey geted=null;
	   PublicKey geted1=null;
	   try(ObjectInputStream fis=new ObjectInputStream(new FileInputStream("pubKey")))
	      {
	    	  geted=(PublicKey) fis.readObject();
	      }
	   try(ObjectInputStream fis=new ObjectInputStream(new FileInputStream("pubKey1")))
	      {
	    	  geted1=(PublicKey) fis.readObject();
	      }
	   System.out.println(geted.equals(geted1));
	   System.out.println("PublicKey"+geted.toString());
	   Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	   cipher.init(Cipher.DECRYPT_MODE, pr);
	   byte[] decipheredText = cipher.doFinal(er);
	   return new String(decipheredText);
   }
   public static void main(String args[]) throws Exception{
	   //Creating a Signature object
      byte[] er=Encryp("CVALUE");
      System.out.println(er);
      String dr=decryption(er);
      System.out.println(dr);
   }
}