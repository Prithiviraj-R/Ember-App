//$Id$
package Details;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class Authentication 
{
	PublicKey publicKeyServer2=null;
	PublicKey pubkkey=null;
	PrivateKey privKey=null;
	public static void createKeys() throws NoSuchAlgorithmException, FileNotFoundException, IOException, ClassNotFoundException
	{
	    KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
	    keyPairGen.initialize(1024);
	    KeyPair pair = keyPairGen.generateKeyPair(); 
	    PublicKey pubKey=pair.getPublic();
	    try(ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("ServerPubKey")))
	    {
	    	oos.writeObject(pubKey);
	    }
	    try(ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("ServerPrivKey")))
	    {
	    	oos.writeObject(pair.getPrivate());
	    }
	}
	
	public byte[] encrpt(String dataToEncript) throws NoSuchAlgorithmException, NoSuchPaddingException, FileNotFoundException, IOException, ClassNotFoundException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, SignatureException
	{
	     Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	     if(publicKeyServer2==null)
	     {
	    	 try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream("ServerPubKey")))
			 {
				publicKeyServer2=(PublicKey) ois.readObject(); 
			 } 
	     }
	     cipher.init(Cipher.ENCRYPT_MODE, publicKeyServer2);
	     byte[] input = dataToEncript.getBytes();	  
	     cipher.update(input);
	     byte[] cipherText = cipher.doFinal();
	     return cipherText;
	}
	
	public Object decrypt(byte[] cipheredOne) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, FileNotFoundException, IOException, ClassNotFoundException
	{
		   Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		   if(privKey==null)
		   {
	    	 try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream("ServerPrivKey")))
			 {
				privKey=(PrivateKey) ois.readObject(); 
			 } 
		   }
		   cipher.init(Cipher.DECRYPT_MODE, privKey);
		   byte[] decipheredText = cipher.doFinal(cipheredOne);
		   return decipheredText;
	}
	
	public Object[] createSign(byte[] cipherContent) throws NoSuchAlgorithmException, InvalidKeyException, SignatureException, FileNotFoundException, IOException, ClassNotFoundException
	{
		 Signature sign = Signature.getInstance("SHA1withRSA");
		   if(privKey==null)
		   {
	    	 try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream("ServerPrivKey")))
			 {
				privKey=(PrivateKey) ois.readObject(); 
				System.out.println(privKey);
			 } 
		   }
	     sign.initSign(privKey);
	     byte[] bytes = "AshokaBank".getBytes();
	     sign.update(bytes);
	     byte[] signature = sign.sign();
	     Object[] arrOfContents= {cipherContent,signature};
		 return arrOfContents;  
	}
	
	public boolean verifySign(byte[] signature) throws NoSuchAlgorithmException, InvalidKeyException, SignatureException, FileNotFoundException, IOException, ClassNotFoundException
	{
		Signature sign = Signature.getInstance("SHA1withRSA");
		 if(publicKeyServer2==null)
	     {
	    	 try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream("pubKeyServer2")))
			 {
				publicKeyServer2=(PublicKey) ois.readObject(); 
			 } 
	     }
	    sign.initVerify(publicKeyServer2);
	    String server2Signature=null;
	    try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream("SignatureBank2")))
		 {
	    	server2Signature=(String) ois.readObject(); 
		 }
	    byte[] bytes = server2Signature.getBytes();
	    sign.update(bytes);
	    boolean bool = sign.verify(signature);
	    return bool;
	}
	
	public static void main(String[] args) throws ClassNotFoundException
	{
//		Authentication auth=new Authentication();
//		try 
//		{
//			auth.createKeys();
//		} 
//		catch (NoSuchAlgorithmException | IOException e) 
//		{
//			e.printStackTrace();
//		}		
	}
}
