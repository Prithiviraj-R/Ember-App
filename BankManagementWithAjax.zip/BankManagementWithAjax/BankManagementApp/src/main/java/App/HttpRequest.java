//$Id$
package App;
 
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.google.gson.Gson;

import Details.Authentication;

public class HttpRequest 
{
	public String internalServerCall() throws IOException
	{
		URL url = new URL("http://172.24.226.130:8080/EmberTask/customer");
        String postData = "{\"customerName\":\"Kumaraguru\",\"address\":\"Secundarabad\",\"mobile\":\"9090808777\"}";
        Authentication auth =new Authentication();
//        auth.encrpt(postData);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        try (DataOutputStream dos = new DataOutputStream(conn.getOutputStream())) {
            dos.writeBytes(postData);
        }
        try (BufferedReader br = new BufferedReader(new InputStreamReader(
                                            conn.getInputStream())))
        {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        }
		return null;
	}
	public static void main(String[] args)
    {
        try {
        	URL url = new URL("http://172.24.226.130:8080/appbank/login/customer/");
            String postData = "{\"customerName\":\"Hariharan\",\"address\":\"KKDI\",\"mobile\":\"9090808777\"}";
            Authentication auth =new Authentication();
            byte[] arr1=auth.encrpt(postData);
            Object[] arrOP=auth.createSign(arr1);
            JSONArray jsArr=new JSONArray();
//            jsArr.add(new Gson().toJson(arrOP[0]));
            jsArr.add(postData);
            jsArr.add(new Gson().toJson(arrOP[1]));
            JSONObject jsObj=new JSONObject();
            jsObj.put("content",jsArr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            try (DataOutputStream dos = new DataOutputStream(conn.getOutputStream())) {
                dos.writeBytes(jsObj.toString());
            }
            try (BufferedReader br = new BufferedReader(new InputStreamReader(
                                                conn.getInputStream())))
            {
                String line;
                while ((line = br.readLine()) != null) {
                    System.out.println(line);
                }
            }
        } 
        catch(ConnectException ex)
        {
        	ex.printStackTrace();
        	System.out.println("Server Probelm Occurs,please try Again Later");	
        }
        catch(NullPointerException ex)
        {
        	ex.printStackTrace();
        	System.out.println("Data is Not available");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
