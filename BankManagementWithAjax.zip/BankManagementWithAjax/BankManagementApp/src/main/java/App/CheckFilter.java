package App;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class CheckFilter
 */
@WebFilter("/user/*")
public class CheckFilter implements Filter {

	/**
	 * Default constructor.
	 */
	public CheckFilter() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;
		// StringBuffer jb = new StringBuffer();
		// String line = null;
		// BufferedReader reader = request.getReader();
		//// System.out.println(request.getReader().toString());
		// while ((line = reader.readLine()) != null)
		// {
		// jb.append(line);
		// }
		Cookie[] cookies = request.getCookies();
		System.out.println("Cookies ::: "+ Arrays.toString(cookies));
		
		if (cookies != null) 
		{
			for (Cookie aCookie : cookies)
			{
//				String name = aCookie.getName();
				String value = aCookie.getValue();
				System.out.println(" " + value);
			}
		}
	    chain.doFilter(request, response);
	}

	/**
	 * @throws IOException
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
	}

}
