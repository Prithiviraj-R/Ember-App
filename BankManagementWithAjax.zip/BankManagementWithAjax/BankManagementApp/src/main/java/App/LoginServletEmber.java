package App;

import java.io.BufferedReader;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
//import org.apache.tomcat.util.http.parser.Cookie;
//import org.json.Cookie;
import org.json.JSONObject;

import Details.Encryption;
import logic_With_persistence.LogicLayer;
import newexception.MistakeOccuredException;

/**
 * Servlet implementation class LoginServletEmber
 */
@WebServlet("/login")
public class LoginServletEmber extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServletEmber() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	private JSONObject stringToJsonObject(String jb)
	{
		JSONObject wholeData = new JSONObject(); 
		String [] splitArr=jb.toString().split("&");
		for(int i=0;i<splitArr.length;i++)
		{
			String[] arr=splitArr[i].split("=");
			System.out.println(arr.length);
			wholeData.put(arr[0],arr[1]);
		}
		return  wholeData;
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try
		{
		LogicLayer obj=new LogicLayer(false);
		StringBuffer jb = new StringBuffer();
		String line = null;
		BufferedReader reader = request.getReader();
		Encryption ec=new Encryption();
		while ((line = reader.readLine()) != null)
		{
		  jb.append(line);  
		}
		System.out.println(jb.toString());
		JSONObject roleIdentify=new JSONObject(jb.toString());
//		JSONObject roleIdentify=stringToJsonObject(jb.toString());
		System.out.println((String)roleIdentify.get("userName"));
		boolean role=obj.getRole((String)roleIdentify.get("userName"),(String)roleIdentify.get("password"));
		System.out.println("hole"+role);
		if (role==false) 
		{
			JSONObject roleDefine=new JSONObject();
			roleDefine.put("role", "false");
			response.setContentType("application/json");
			byte[] arr=ec.Encryp("cvalue");
			String strqa=arr.toString();
			response.setHeader("outAt", strqa);
			response.getWriter().write(roleDefine.toString());
		}
		else if(role==true)
		{
			JSONObject roleDefine=new JSONObject();
			roleDefine.put("role", "true");
			response.setContentType("application/json");
			byte[] arr=ec.Encryp("cvalue");
			String strqa=arr.toString();
			response.setHeader("outAt", strqa);
			response.getWriter().write(roleDefine.toString());
		}
		}
		catch(MistakeOccuredException ex)
		{
			ex.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		doGet(request, response);
	}

}
