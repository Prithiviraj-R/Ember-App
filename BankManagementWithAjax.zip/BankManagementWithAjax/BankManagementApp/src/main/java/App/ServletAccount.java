package App;


import java.io.BufferedReader;
import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import Details.AccountDetails;
import logic_With_persistence.LogicLayer;
import newexception.MistakeOccuredException;

/**
 * Servlet implementation class ServletAccount
 */
public class ServletAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletAccount() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		String uri=request.getRequestURI();
		String[] splitedUrl=uri.split("/");
		StringBuffer jb = new StringBuffer();
		String line = null;
		BufferedReader reader = request.getReader();
		while ((line = reader.readLine()) != null)
		{
		  jb.append(line);  
		}
		if(splitedUrl[splitedUrl.length-1].equals("account"))
		{
			LogicLayer logic=new LogicLayer(false);
			try 
			{
				Map<Integer,Map<Long,AccountDetails>> mapObj=logic.getAllAccount();
				JSONArray jsArr=toJsonArray(mapObj);
				response.setContentType("application/json");
				response.getWriter().write(jsArr.toString());
			} 
			catch (MistakeOccuredException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	private JSONArray toJsonArray(Map<Integer,Map<Long,AccountDetails>> mapObj) 
	{
		JSONArray arrObj=new JSONArray();
		for(Integer cusId:mapObj.keySet())
		{
			for(Long accNo:mapObj.get(cusId).keySet())
			{
				JSONObject objJson=new JSONObject();
				AccountDetails jsonObj	= mapObj.get(cusId).get(accNo);
				System.out.println(jsonObj.toString());
				objJson.put("CustId",jsonObj.getCustomerId());
				objJson.put("accNo", jsonObj.getAccountNumber());
				objJson.put("branch", jsonObj.getBranch());
				objJson.put("balance",jsonObj.getBalance());
				objJson.put("status", jsonObj.isStatus());
				arrObj.put(objJson);
			}
		}
		System.out.println(arrObj);
		return arrObj;
	}
//	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
//	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
//		AccountDetails accDetails=new AccountDetails();
//	    accDetails.setCustomerId(id);
//	    accDetails.setBranch(branch);
//	    accDetails.setBalance(amount);
//		obj.accountToCustomerId((int) id,accDetails);
		String uri=request.getRequestURI();
		System.out.println("uri");
		String[] splitedUrl=uri.split("/");
		StringBuffer jb = new StringBuffer();
		String line = null;
		BufferedReader reader = request.getReader();
		while ((line = reader.readLine()) != null)
		{
		  jb.append(line);  
		}
		if(splitedUrl[splitedUrl.length-1].equals("account"))
		{
			JSONParser customerDet=new JSONParser();
			JSONObject objJs=null;
			LogicLayer logic=new LogicLayer(false);
			try 
			{
				objJs=(JSONObject) customerDet.parse(jb.toString());
				AccountDetails accDetails=new AccountDetails();
				accDetails.setCustomerId(Integer.parseInt((String) objJs.get("custId")));
				accDetails.setBranch((String) objJs.get("branch"));
				accDetails.setBalance(Double.parseDouble( (String) objJs.get("balance") ));
				long accNo=logic.accountToCustomerId(Integer.parseInt((String) objJs.get("custId")),accDetails);
				JSONObject jsonObj = new JSONObject();
			    jsonObj.put("sucess", "Account Added Sucessfully");
			    jsonObj.put("accNo",accNo);
		        response.setContentType("application/json");
	    		response.getWriter().write(jsonObj.toString());	
			}
			catch (ParseException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MistakeOccuredException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
		else if(splitedUrl[splitedUrl.length-1].equals("status"))
		{
			JSONParser customerDet=new JSONParser();
			JSONObject objJs=null;
			LogicLayer logic=new LogicLayer(false);
			try 
			{
				objJs=(JSONObject) customerDet.parse(jb.toString());
				logic.setAccountStatus(Integer.parseInt((String) objJs.get("custId")), Long.parseLong((String) objJs.get("accNo")),Integer.parseInt((String) objJs.get("statusD")));
				JSONObject jsonObj = new JSONObject();
			    jsonObj.put("sucess", "Account Added Sucessfully");
		        response.setContentType("application/json");
	    		response.getWriter().write(jsonObj.toString());	
			}
			catch (ParseException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MistakeOccuredException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}
	}

}
