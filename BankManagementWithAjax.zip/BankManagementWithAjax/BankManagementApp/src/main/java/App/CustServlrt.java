package App;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import Details.Customer;
import logic_With_persistence.LogicLayer;
import newexception.MistakeOccuredException;

/**
 * Servlet implementation class CustServlrt
 */
@WebServlet("/admin/customer/*")
public class CustServlrt extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustServlrt() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uri=request.getRequestURI();
		String[] splitedUrl=uri.split("/");
		if(splitedUrl[splitedUrl.length-1].equals("customer"))
		{
			LogicLayer logic=new LogicLayer(false);
			try
			{
				Map<Integer,Customer> cusDetails=logic.getactiveCustomer();
				JSONArray jsonArr=toJsonArray(cusDetails);
				Map<Integer,Customer> InActCusDetails=logic.getInactiveCustomer();
				JSONArray jsonArr1=toJsonArray(InActCusDetails);
				JSONArray jsonAr=new JSONArray();
				jsonAr.put(jsonArr);
				jsonAr.put(jsonArr1);
				response.getWriter().write(jsonAr.toString());
			} 
			catch (MistakeOccuredException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
//	response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	private JSONArray toJsonArray(Map<Integer,Customer> mapObj) 
	{
		JSONArray arrObj=new JSONArray();
		for(Integer cusId:mapObj.keySet())
		{
			JSONObject objJson=new JSONObject();
			Customer jsonObj	= mapObj.get(cusId);
			System.out.println(jsonObj.toString());
			objJson.put("CustId",jsonObj.getCustomerId());
			objJson.put("name", jsonObj.getName());
			objJson.put("dob", jsonObj.getDob());
			objJson.put("address",jsonObj.getAddress());
			objJson.put("phNo",jsonObj.getPhoneNumber());
			arrObj.put(objJson);
		}
		System.out.println(arrObj);
		return arrObj;
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uri=request.getRequestURI();
		System.out.println("uri");
		String[] splitedUrl=uri.split("/");
		StringBuffer jb = new StringBuffer();
		String line = null;
		BufferedReader reader = request.getReader();
		while ((line = reader.readLine()) != null)
		{
		  jb.append(line);  
		}
		if(splitedUrl[splitedUrl.length-1].equals("add"))
		{
			JSONParser customerDet=new JSONParser();
			JSONObject objJs=null;
			try
			{
				LogicLayer logic=new LogicLayer(false);
				objJs=(JSONObject) customerDet.parse(jb.toString());
				Customer cusObj=new Customer();
				cusObj.setName((String) objJs.get("custName"));
				cusObj.setDob((String) objJs.get("dob"));
				cusObj.setAddress((String) objJs.get("address"));
				cusObj.setPhoneNumber(Long.parseLong((String)objJs.get("phNo")));
				int id=logic.addCustomerInfo(cusObj);
				JSONObject jsonObj = new JSONObject();
			    jsonObj.put("sucess", "Customer Added Sucessfully");
			    jsonObj.put("CustId" , id);
		        response.setContentType("application/json");
	    		response.getWriter().write(jsonObj.toString());	
			}
			catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch(MistakeOccuredException ex)
			{
				ex.printStackTrace();
			}
		}
		else if(splitedUrl[splitedUrl.length-1].matches("[0-9]"))
		{
			JSONParser customerDet=new JSONParser();
			JSONObject objJs=null;
			try
			{
				LogicLayer logic=new LogicLayer(false);
				objJs=(JSONObject) customerDet.parse(jb.toString());
//				Customer cusObj=new Customer();
//				cusObj.setName((String) objJs.get("custName"));
//				cusObj.setDob((String) objJs.get("dob"));
//				cusObj.setAddress((String) objJs.get("address"));
				long phNo= Long.parseLong((String) objJs.get("phNo"));
				System.out.println(phNo);
				System.out.println(objJs.get("custId").getClass().getName());
//				int id=logic.addCustomerInfo(cusObj);
				logic.updateCustomer(Integer.parseInt((String)objJs.get("custId")), (String) objJs.get("custName"), (String) objJs.get("dob"), (String) objJs.get("address"),phNo);
				JSONObject jsonObj = new JSONObject();
			    jsonObj.put("sucess", "Customer updated Sucessfully");
		        response.setContentType("application/json");
	    		response.getWriter().write(jsonObj.toString());	
			}
			catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch(MistakeOccuredException ex)
			{
				ex.printStackTrace();
			}
		}
		else if(splitedUrl[splitedUrl.length-1].equals("change"))
		{
			JSONParser customerDet=new JSONParser();
			JSONObject objJs=null;
			try
			{
				System.out.println(splitedUrl[splitedUrl.length-2]);
				LogicLayer logic=new LogicLayer(false);
				objJs=(JSONObject) customerDet.parse(jb.toString());
				logic.setCustomerStatus(Integer.parseInt((String) objJs.get("custId")),Integer.parseInt((String) objJs.get("statusD")));
				JSONObject jsonObj = new JSONObject();
		        jsonObj.put("sucess", "Customer Status Changed");
		        response.setContentType("application/json");
	    		response.getWriter().write(jsonObj.toString());	
			}
			catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch(MistakeOccuredException ex)
			{
				ex.printStackTrace();
			}
		}
	}

}
