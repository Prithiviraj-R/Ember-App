package App;

import java.io.BufferedReader;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import logic_With_persistence.LogicLayer;
import newexception.MistakeOccuredException;

/**
 * Servlet implementation class servletContent
 */
//@WebServlet("/bankadmin/*")
public class servletContent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servletContent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uri=request.getRequestURI();
		System.out.println(uri);
		String[] splitedUrl=uri.split("/");
		StringBuffer jb = new StringBuffer();
		String line = null;
		BufferedReader reader = request.getReader();
		while ((line = reader.readLine()) != null)
		{
		  jb.append(line);  
		}
		System.out.println(jb.toString());
		if(splitedUrl[splitedUrl.length-1].equals("deposit"))
		{
			JSONParser customerDet=new JSONParser();
			JSONObject objJs=null;
			try {
			objJs=(JSONObject) customerDet.parse(jb.toString());
		    LogicLayer logic=new LogicLayer(false);
		    System.out.println(objJs.get("custId"));
		    System.out.println(Integer.parseInt((String)objJs.get("custId")));
			logic.deposit(Integer.parseInt((String)objJs.get("custId")), Long.parseLong((String)objJs.get("accNo")),Double.parseDouble((String)objJs.get("amount")));
			JSONObject jsonObj = new JSONObject();
		    jsonObj.put("sucess", "Deposited Sucessfully");
	        response.setContentType("application/json");
    		response.getWriter().write(jsonObj.toString());	
			} 
			catch (NumberFormatException | MistakeOccuredException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			catch (ParseException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else if(splitedUrl[splitedUrl.length-1].equals("withdraw"))
		{
			JSONParser customerDet=new JSONParser();
			JSONObject objJs=null;
			try {
			objJs=(JSONObject) customerDet.parse(jb.toString());
		    LogicLayer logic=new LogicLayer(false);
		    System.out.println(objJs.get("custId"));
		    System.out.println(Integer.parseInt((String)objJs.get("custId")));
			logic.withDraw(Integer.parseInt((String)objJs.get("custId")), Long.parseLong((String)objJs.get("accNo")),Double.parseDouble((String)objJs.get("amount")));
			JSONObject jsonObj = new JSONObject();
		    jsonObj.put("sucess", "Deposited Sucessfully");
	        response.setContentType("application/json");
    		response.getWriter().write(jsonObj.toString());	
			} 
			catch (NumberFormatException | MistakeOccuredException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			catch (ParseException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
//		doGet(request, response);
	}

}
