package App;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;

import Details.AccountDetails;
import Details.Customer;
import logic_With_persistence.LogicLayer;
import newexception.MistakeOccuredException;
import util.HelperUtil;

/**
 * Servlet implementation class SingleServlet
 */
@WebServlet("/user/*")
public class SingleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SingleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url=request.getRequestURL().toString();
		System.out.println(url);
        int lastIndexOf=url.lastIndexOf("/");
        String func=url.substring(lastIndexOf+1);
        String[] urlElements=url.split("/");
        System.out.println(urlElements[urlElements.length-1]);
        if(func.matches("[0-9]"))
        {
			try 
    		{
//				LogicLayer obj=(LogicLayer) request.getServletContext().getAttribute("Object");
	    	    LogicLayer obj=new LogicLayer(false);
				Map<Long,AccountDetails> account=obj.getAccountdetails(Integer.parseInt(func));
				System.out.println(account);
				response.setContentType("application/json");
				Customer cusObj=obj.getCustomerDetails(Integer.parseInt(func));
				JSONObject accountList=new JSONObject();
				accountList.put("accountDetails",account);
				JSONArray one=toJsonArray(account,cusObj);
				System.out.println(one);
				response.setContentType("application/json");
				response.getWriter().write(one.toString());
    		} 
			catch (MistakeOccuredException e) 
			{
				e.printStackTrace();
				JSONObject errorMsg = new JSONObject();
				errorMsg.put("text","Details cannot be fetched.");
				response.getWriter().write(new Gson().toJson(errorMsg));
			}
        }
        else if(urlElements[urlElements.length-1].equals("profile"))
        {
//        	LogicLayer obj=(LogicLayer) request.getServletContext().getAttribute("Object");
    	    LogicLayer obj=new LogicLayer(false);
			HttpSession session=request.getSession();
			Customer cusObj=null;
			AccountDetails accObj=null;
			JSONObject customerDetails=null;
			try 
			{
				cusObj=obj.getCustomerDetails(Integer.parseInt(urlElements[urlElements.length-2]));
				System.out.println(cusObj);
				customerDetails=new JSONObject();
				customerDetails.put("customerName", cusObj.getName());
				customerDetails.put("DOB", cusObj.getDob());
				customerDetails.put("address", cusObj.getAddress());
				customerDetails.put("phoneNumber", cusObj.getPhoneNumber());
				System.out.println(customerDetails);
				response.setContentType("application/json");
				response.getWriter().write(customerDetails.toString());
			}
			catch (MistakeOccuredException e) 
			{
				e.printStackTrace();
			}
//        	
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	private JSONArray toJsonArray(Map<Long,AccountDetails> mapObj,Customer custObj) 
	{
		JSONArray arrObj=new JSONArray();
		for(Long accNo:mapObj.keySet())
		{
			JSONObject objJson=new JSONObject();
			AccountDetails jsonObj	= mapObj.get(accNo);
			objJson.put("accountNumber", jsonObj.getAccountNumber());
			objJson.put("customerId", jsonObj.getCustomerId());
			objJson.put("balance",jsonObj.getBalance());
			objJson.put("branch", jsonObj.getBranch());
			arrObj.put(objJson);
		}
		System.out.println(arrObj);
		return arrObj;
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String url=request.getRequestURL().toString();
        int lastIndexOf=url.lastIndexOf("/");
        String func=url.substring(lastIndexOf+1);
        if(func.equals("transfer"))
        {
        	try 
        	{
				transferMoney(request, response);
			} 
        	catch (Exception e) 
        	{
				e.printStackTrace();
			}
        }
        if(func.equals("deposit"))
        {
        	try 
        	{
				depositMoney(request, response);
			} 
        	catch (Exception e) 
        	{
				e.printStackTrace();
			}
        }
        if(func.equals("withdraw"))
        {
        	try 
        	{
				withdrawMoney(request, response);
			} 
        	catch (Exception e) 
        	{
				e.printStackTrace();
			}
        }
	}
    private void transferMoney(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
    {
    	try 
		{ 
				StringBuffer jb = new StringBuffer();
				String line = null;
				BufferedReader reader = request.getReader();
				while ((line = reader.readLine()) != null)
				{
				  jb.append(line);  
				}
//		        JSONParser parser = new JSONParser();  
//		        wholeData = (JSONObject) parser.parse(jb.toString()); 
//				LogicLayer obj=(LogicLayer) request.getServletContext().getAttribute("Object");
				JSONObject wholeData=stringToJsonObject(jb.toString());
		        LogicLayer obj=new LogicLayer(false);
				HelperUtil.stringCheck((String) wholeData.get("fromAccNo"));
				HelperUtil.stringCheck((String) wholeData.get("toAccNo"));
				HelperUtil.stringCheck((String) wholeData.get("amount"));
			    long fromAccNo=Long.parseLong((String) wholeData.get("fromAccNo"));
			    long toAccNo=Long.parseLong((String) wholeData.get("toAccNo"));
			    double amount=Double.parseDouble((String) wholeData.get("amount"));
				obj.amountTransfer(fromAccNo, toAccNo, amount);
				JSONObject jsonObj = new JSONObject();
		        jsonObj.put("sucess", "Amount Transferred");
		        response.setContentType("application/json");
	    		response.getWriter().write(jsonObj.toString());	
		}
		catch (MistakeOccuredException e) 
		{
			e.printStackTrace();
		}
    }
    private void depositMoney(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException, ParseException
    {
    	try 
		{ 
    		JSONObject wholeData=null;
	    		String url=request.getRequestURL().toString();
	    		System.out.println("hello"+url);
	            String[] func=url.split("/");
	            String id=func[func.length-4];
				StringBuffer jb = new StringBuffer();
				String line = null;
				BufferedReader reader = request.getReader();
//				System.out.println(request.getReader().toString());
				while ((line = reader.readLine()) != null)
				{
				  jb.append(line);  
				}
				System.out.println("line 196:"+jb);
				wholeData=stringToJsonObject(jb.toString());
//				wholeData = new JSONObject(jb.toString());  
//				wholeData=toJSONObject(jb.toString());
//		        JSONParser parser = new JSONParser(); 
//		        wholeData = (JSONObject) parser.parse(jb.toString()); 
		        System.out.println("line 199:"+wholeData);
//				LogicLayer obj=(LogicLayer) request.getServletContext().getAttribute("Object");
		        LogicLayer obj=new LogicLayer(false);
		        response.setContentType("application/json");
		        System.out.println(id);
		        obj.deposit(Integer.parseInt(id), Long.parseLong((String) wholeData.get("accNo")), Double.parseDouble((String) wholeData.get("amount")));
		        JSONObject jsonObj = new JSONObject();
		        jsonObj.put("sucess", "Deposited");
	    		response.getWriter().write(jsonObj.toString());		
	    }
		catch (MistakeOccuredException e) 
		{
			e.printStackTrace();
		}
    }
    
	private void withdrawMoney(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
    {
    	try 
		{ 
	    		String url=request.getRequestURL().toString();
	    		System.out.println(url);
	            String[] func=url.split("/");
	            System.out.println(func.length);
	            System.out.println("Not well");
	            String id=func[func.length-4];
				StringBuffer jb = new StringBuffer();
				String line = null;
				BufferedReader reader = request.getReader();
				while ((line = reader.readLine()) != null)
				{
				  jb.append(line);  
				}
				System.out.println("soul"+jb);
				JSONObject wholeData=stringToJsonObject(jb.toString());
//		        JSONParser parser = new JSONParser();  
//		        wholeData = (JSONObject) parser.parse(jb.toString()); 
//				LogicLayer obj=(LogicLayer) request.getServletContext().getAttribute("Object");
		        LogicLayer obj=new LogicLayer(false);
		        obj.withDraw(Integer.parseInt(id), Long.parseLong((String) wholeData.get("accNo")), Double.parseDouble((String) wholeData.get("amount")));
	    		JSONObject jsonObj = new JSONObject();
	    		response.setContentType("application/json");
		        jsonObj.put("sucess", "Withdrawed");
	    		response.getWriter().write(jsonObj.toString());	
	    }
		catch (MistakeOccuredException e) 
		{
			e.printStackTrace();
		}
    }
	
	private JSONObject stringToJsonObject(String jb)
	{
		JSONObject wholeData = new JSONObject(); 
		String [] splitArr=jb.toString().split("&");
		for(int i=0;i<splitArr.length;i++)
		{
			String[] arr=splitArr[i].split("=");
			System.out.println(Arrays.toString(arr));
			System.out.println(arr.length);
			wholeData.put(arr[0],arr[1]);
		}
		return  wholeData;
	}
}
