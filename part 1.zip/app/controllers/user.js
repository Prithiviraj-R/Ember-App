import Ember from 'ember';

export default Ember.Controller.extend({
    service:Ember.inject.service('cust-details'),
    show:true,
    divClose:true,
    num:2,
    fullName:Ember.computed('appController',function(){ 
        var currentPost = this.get('service');
        return currentPost.getName('userName');
    }),
    customerId:Ember.computed(
        function()
        {
            var currentPost = this.get('service');
            return currentPost.getName('userName');
        }
    ),
    sizeOfTable:Ember.computed(function()
    {
            return this.get('service').get('size');
    }),
    actions:
    {

        cssOpt:function()
        {
            if(this.get('show')==false)
            {
                event.stopPropagation();
                if(event.target.innerText=="Deposit")
                {
                    $(event.target).css('color','green');
                }
                else if(event.target.innerText=="Withdraw")
                {
                    $(event.target).css('color','red');
                }
                else if(event.target.innerText=="Transfer")
                {
                    $(event.target).css('color','orange');
                }
            }
        },

        showBalance:function()
        {
            console.log(event.target);
            if($('.balance').attr('type')=='password')
            {
                $('.balance').attr('type','text')
            }
            else
            {
                $('.balance').attr('type','password')
            }
        },

        showOptions:function()
        {
            var emb=event.target.id;
            if(this.get('divClose')==true)
            {
                event.stopPropagation();
            }
            if(this.get('show')==true)
            {
                Ember.$('#'+emb+ '.user_options').css('display','block');
                this.set('show',false);
                this.set('divClose',false);
            }
            else if(this.get('show')==false)
            {
                Ember.$('#'+emb + '.user_options').css('display','none');
                this.set('show',true);
            }
        },
         
        hideAll:function()
        {
            // if(this.get('divClose')==true)
            // {
            //     event.stopPropagation();
            // }
            if(this.get('divClose')==false)
            {
                Ember.$('.user_options').css({'display':'none'});
                this.set('divClose',true);
                this.set('show',true);
            }
        },
        log_out:function()
        {
            if(this.get('divClose')==true)
            {
                event.stopPropagation();
            }
            this.transitionToRoute('login');
        }
    }
});
