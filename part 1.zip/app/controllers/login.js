import Ember from 'ember';

export default Ember.Controller.extend({
    // appController: Ember.inject.controller('application'),
    service:Ember.inject.service('cust-details'),
    // userController: Ember.inject.controller('user'),
    actions:
    {
        login:function()
        {
            var _this=this;
            var userName=this.get('userName');
            this.get('service').set('custId',userName);
            // console.log(this.get('password'));
            var datas=JSON.stringify({
                userName:this.get('userName'),
                password:this.get('password')
            });
            // Ember.$.post("http://localhost:8080/BankManagementWithAjax/login",data,function(result)
            // {
            //     debugger;
            //         if(result.role=='false')
            //         {
            //             const d = new Date();
            //             d.setTime(d.getTime() + (0.01*24*60*60*1000));
            //             let expires = "expires="+ d.toUTCString();
            //             document.cookie = 'cname' + "=" + 'cvalue' + ";" + expires + ";path=/"
            //             _this.set('userId',userName);
            //             _this.transitionToRoute('user', userName);
            //         }
            //         else
            //         {
            //             console.log('hell'+data);
            //             _this.set('wrongAct','Enter the valid Credentials');
            //         }
            // }).fail(function(result)
            // {
            //     console.log(result)
            //     console.log("ERROR")
            // })
            var xhr=Ember.$.ajax( {
                type: 'POST',
                data:datas,
                dataType:'json',
                crossDomain: true,
                url:"http://localhost:8080/BankManagementWithAjax/login",
                success: function(result,jqXHR)
                {
                    // debugger;
                    // var num=xhr.getResponseHeader('outAt');
                    // console.log(num);
                    const d = new Date();
                    d.setTime(d.getTime() + (1*24*60*60*1000));
                    let expires = "expires="+ d.toUTCString();
                    document.cookie = 'cname' + "=" + 'cvalue' + ";" + expires + ";path=/"
                    console.log(datas);
                    console.log('iam'+result.role);
                        if(result.role=='false')
                        {
                            _this.set('role',result.role)
                            _this.get('service').set('custId',userName);
                            _this.set('userId',userName);
                            _this.transitionToRoute('user', userName);
                        }
                        else if(result.role=='true')
                        {
                            debugger;
                            _this.set('role',result.role)
                            _this.get('service').set('custId',userName);
                            _this.transitionToRoute('admin');
                        }
                        else
                        {
                            _this.set('wrongAct','Enter the valid Credentials');
                        }
                },
                error: function(result)
                {
                    debugger;
                    console.log(result)
                    console.log("ERROR")
                }
            });
            if(_this.get('role')==false)
            {
                Ember.$.get("http://localhost:8080/BankManagementWithAjax/user/"+_this.get('userName')+"/profile",function(result)
                {
                    // debugger;
                    console.log('userId',_this.get('userName'))
                    // console.log(result.customerName);
                    _this.get('service').setName(result.customerName);
                    console.log(_this.get('service').getName('userName'));
                    // _this.get('appController').set('userDetails',result.customerName);
                    // debugger;
                    // _this.get('userController').send('postTitle');
                    
                }).fail(function()
                {
                    console.log("ERROR");
                })
            }
        }
    }
});
