import Ember from 'ember';

export default Ember.Controller.extend({
    actions:
    {
        statusChange:function()
        {
            var accDet=JSON.stringify({
                custId:this.model.customerId,accNo:this.model.AccNum,statusD:this.get('status')
            });
            Ember.$.ajax(
                {
                    type:'post',
                    data:accDet,
                    dataType:'json',
                    url:'http://localhost:8080/BankManagementWithAjax/admin/account/'+this.model.AccNum+'/status'
                    ,success:function(result)
                    {
                        console.log('win')
                    }
                    ,error:function(result)
                    {
                        console.log('lose')
                    }
                }
            )
        }
    }
});
