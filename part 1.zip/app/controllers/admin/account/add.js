import Ember from 'ember';

export default Ember.Controller.extend({
    controller:Ember.inject.controller('admin.account'),
    actions:
    {
        addAccount:function()
        {
            var _this=this;
            var accDet=JSON.stringify({
                custId:this.get('cus_Id'),branch:this.get('branch'),balance:this.get('balance')
            });
            Ember.$.ajax(
                {
                    type:'post',
                    data:accDet,
                    dataType:'json',
                    url:'http://localhost:8080/BankManagementWithAjax/admin/account'
                    ,success:function(result)
                    {
                        var accountPage=_this.get('controller').get('model');
                        var newObj={CustId:_this.get('cus_Id'),accNo:result.accNo,branch:_this.get('branch'),balance:_this.get('balance')}
                        accountPage.insertAt(accountPage.length,newObj);
                    },
                    error:function(result)
                    {
                        console.log('lose')
                    }
                }
            )
        }
    }
});
