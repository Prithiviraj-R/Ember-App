import Ember from 'ember';

export default Ember.Controller.extend({
    isValue:true,
    activeCus:Ember.computed('isValue',function()
    {
        return this.get('isValue')?this.model[0]:this.model[1];
    }),
    buttonName:Ember.computed('isValue',function()
    {
        return this.get('isValue')?"Inactive":"Active";
    }),
    actions:
    {
        onClick:function()
        {
            this.toggleProperty('isValue');
        }
    }
});
