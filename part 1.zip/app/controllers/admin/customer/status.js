import Ember from 'ember';

export default Ember.Controller.extend({
    actions:
    {
        statusChange:function()
        {
            var _this=this;
            var statusDetails=JSON.stringify({
                statusD:this.get('status')
            });
            Ember.$.ajax({
                type:'post',
                url:"http://localhost:8080/BankManagementWithAjax/admin/customer/"+_this.model.custId+"/change",
                data:statusDetails,
                success:function(result)
                {
                    console.log('iam')
                    console.log(result)
                },
                error:function(result)
                {
                    console.log(_this.model.custId)
                    console.log('ji')
                }
            })
        }
    }
});
