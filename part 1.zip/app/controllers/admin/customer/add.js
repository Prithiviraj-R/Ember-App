import Ember from 'ember';

export default Ember.Controller.extend({
    controller:Ember.inject.controller('admin.customer'),
    actions:
    {
        add:function()
        {
            var _this=this;
            var cust_details=JSON.stringify({
                custName:this.get('cus_name'),dob:this.get('dob'),address:this.get('address'),phNo:this.get('phoneNumber')
            });
            
            Ember.$.ajax({
                
                type:'post',
                url:'http://localhost:8080/BankManagementWithAjax/admin/customer/add',
                data:cust_details,
                dataType:'json',
                success:function(result)
                {
                    _this.set('answer',result.sucess);
                    var customerPage=_this.get('controller').get('model');
                    console.log(customerPage);
                    for (var i=0;i<customerPage.length;i++)
                    {
                        var actCust=customerPage[i];
                        if(i==0)
                        {
                            // var newCusAdd=actCust[actCust.length+1];
                            var newObj={ 'CustId':result.CustId , 'name':_this.get('cus_name') , 
                            'dob':_this.get('dob') ,'address':_this.get('address'),
                            'phNo':_this.get('phoneNumber')};
                            // newCusAdd.set('CustId',result.CustId);
                            // newCusAdd.set('name',_this.get('cust_details').custName);
                            // newCusAdd.set('dob',_this.get('cust_details').dob);
                            // newCusAdd.set('address',_this.get('cust_details').address);
                            // newCusAdd.set('phNo',_this.get('cust_details').phNo);
                            actCust.insertAt(actCust.length,newObj);
                        }
                    }
                },
                error:function(result)
                {

                }
            })
        }
    }
});
