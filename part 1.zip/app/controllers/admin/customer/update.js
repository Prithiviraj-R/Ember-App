import Ember from 'ember';

export default Ember.Controller.extend({
    custController:Ember.inject.controller('admin.customer'),
    actions:
    {
        update: function () {
            var _this = this;
            var phNum = this.model.phNo;
            var cust_details = JSON.stringify({
                custId: this.model.CustId.toString(), custName: this.model.name, dob: this.model.dob, phNo: phNum.toString(), address: this.model.address
            });
            alert(typeof this.model.CustId)
            Ember.$.ajax({
                type: 'POST',
                url: 'http://localhost:8080/BankManagementWithAjax/admin/customer/' + _this.model.CustId,
                data: cust_details,
                dataType: 'json',
                success: function (result) {
                    _this.set('answer', result.sucess);
                    var getDetails=_this.get('custController').get('model');
                    for(var i=0;i<getDetails.length;i++)
                    {
                        var getDet=getDetails[i];
                        if(i==0)
                        {
                          for(var j=0;j<getDet.length;j++)
                          { 
                              if(getDet[j].CustId==_this.model.CustId)
                              {
                                  Ember.set(getDet[j],'name',_this.model.name);
                                  Ember.set(getDet[j],'dob',_this.model.dob);
                                  Ember.set(getDet[j],'address',_this.model.address);
                                  Ember.set(getDet[j],'phNo',_this.model.phNo)
                              }
                          }
                        }
                    }
                },
                error: function (result) {
                    console.log('sha');
                }
            })
        }
    }
});
