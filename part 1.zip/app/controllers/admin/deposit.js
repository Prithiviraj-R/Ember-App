import Ember from 'ember';
import EmberResolver from 'ember-resolver';

export default Ember.Controller.extend({
    isValue:true,
    customer_ids:Ember.computed(function()
    {
        var model_data=this.model;
        var uniqueArray = [];
        for(var i=0;i<model_data.length;i++)
        {
            if(uniqueArray.indexOf(model_data[i].CustId.toString()) === -1) 
            {
                console.log(uniqueArray.indexOf(model_data[i].CustId.toString()))
                uniqueArray.push(model_data[i].CustId.toString());
            }
        }
        return uniqueArray;
    }),
    account_id:Ember.computed('isValue',function()
    {
        console.log(Ember.$('#cusNo').val());
        var model_data=this.model;
        var uniqueArray=[];
        for(var i=0;i<model_data.length;i++)
        {
            if(model_data[i].CustId.toString()==Ember.$('#cusNo').val())
            {
                uniqueArray.push(model_data[i].accNo.toString());
            }
            
        }
        return uniqueArray;
    }),

    actions:
    {
        click:function(value)
        {
            this.toggleProperty('isValue');
            this.set('rolevalue',value);
            console.log(this.get('rolevalue'));
        },
        storeVal:function(value)
        {
            this.set('accValue',value)
        },
        deposit:function()
        {
            var _this=this;
            var cusId=this.get('rolevalue');
            var accNum=this.get('accValue');
            var datas=JSON.stringify({custId:this.get('rolevalue'),accNo:this.get('accValue')
            ,amount:this.get('amount')});
            
            Ember.$.ajax({
                type:'POST',
                xhrFields: {
                    withCredentials: true
                 },
                crossDomain:true,
                url:'http://localhost:8080/BankManagementWithAjax/bankadmin/deposit',
                data:datas,
                dataType:'json',
                success:function(result)
                {
                    _this.set('answer',result.sucess)
                },
                error:function(result)
                {
                    console.log('errorresult');
                }
            }); 
        }   
    }
});
