import Ember from 'ember';

export default Ember.Controller.extend({
    actions:
    {
       transferAction:function()
        {
            var _this = this;
            var datas={
                'fromAccNo':this.model.accNo,'toAccNo':this.get('toAccNo'),'amount':this.get('amount')
            };
            // Ember.$.post("http://localhost:8080/BankManagementWithAjax/user/"+this.model.cusId+"/accounts/"+this.model.accNo+"/transfer",data,function(result)
            // {
            //         console.log(result);
            //         _this.set('answer',result.sucess);
            //     //    return result.sucess;
            // }).fail(function()
            // {
            //     console.log("ERROR")
            // })
            Ember.$.ajax({
                type:'POST',
                data:datas,
                xhrFields: {
                    withCredentials: true
                 },
                crossDomain:true,
                dataType:'json',
                url:"http://localhost:8080/BankManagementWithAjax/user/"+this.model.cusId+"/accounts/"+this.model.accNo+"/transfer",
                success:function(result)
                {
                        // var details=_this.get('userController').get('model');
                        // for(var i=0;i<details.length;i++)
                        // {
                        //     if(details[i].accountNumber==_this.model.accNo)
                        //     {
                        //         console.log(details[i])
                        //         var balance=details[i].balance;
                        //         Ember.set(details[i],'balance',parseInt(details[i].balance)-parseInt(_this.get('amount')));
                        //         console.log(details[i].balance);
                        //         break;
                        //     }
                        // }
                         console.log(result);
                        _this.set('answer',result.sucess)
                },
                error:function()
                {
                    console.log("ERROR")
                }
            })
        }
    }
});
