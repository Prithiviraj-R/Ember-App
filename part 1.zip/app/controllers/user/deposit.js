import Ember from 'ember';

export default Ember.Controller.extend({
    userController:Ember.inject.controller('user'),
    accNo:Ember.computed(
        function()
        {
           return model.accNo;
        }
    ),
    actions:
    {
       depositAction:function()
        {
            var para;
            var _this = this;
            console.log(this.get('amount'));
            var datas={
                'accNo':this.model.accNo,'amount':this.get('amount')
            };
            // Ember.$.post("http://localhost:8080/BankManagementWithAjax/user/"+this.model.cusId+"/accounts/"+this.model.accNo+"/deposit",data,function(result)
            // {
            //         var details=_this.get('userController').get('model');
            //         for(var i=0;i<details.length;i++)
            //         {
            //             if(details[i].accountNumber==_this.model.accNo)
            //             {
            //                 console.log(details[i])
            //                 var balance=details[i].balance;
            //                 Ember.set(details[i],'balance',parseInt(details[i].balance)+parseInt(_this.get('amount')));
            //                 console.log(details[i].balance);
            //                 break;
            //             }
            //         }
            //          console.log(result);
            //         _this.set('answer',result.sucess)
            // }).fail(function()
            // {
            //     console.log("ERROR")
            // }).done(function(){

            // })
            Ember.$.ajax({
                type:'POST',
                data:datas,
                xhrFields: {
                    withCredentials: true
                 },
                crossDomain:true,
                dataType:'json',
                url:"http://localhost:8080/BankManagementWithAjax/user/"+this.model.cusId+"/accounts/"+this.model.accNo+"/deposit",
                success:function(result)
                {
                        var details=_this.get('userController').get('model');
                        for(var i=0;i<details.length;i++)
                        {
                            if(details[i].accountNumber==_this.model.accNo)
                            {
                                console.log(details[i])
                                var balance=details[i].balance;
                                Ember.set(details[i],'balance',parseInt(details[i].balance)+parseInt(_this.get('amount')));
                                console.log(details[i].balance);
                                break;
                            }
                        }
                         console.log(result);
                        _this.set('answer',result.sucess)
                },
                error:function()
                {
                    console.log("ERROR")
                }
            })

        }
    }
});
