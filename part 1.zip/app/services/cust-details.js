import Ember from 'ember';

export default Ember.Service.extend({
    userName:null,
    custId:null,
    setName(name)
    { 
        window.localStorage.setItem('userName',name);
    },
    remove()
    {
        window.localStorage.remove('userName');
    },
    getName(givenName)
    {
        return window.localStorage.getItem(givenName);
    }
});
