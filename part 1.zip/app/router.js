import Ember from 'ember';
import config from './config/environment';

const Router = Ember.Router.extend({
  location: config.locationType,
  rootURL: config.rootURL
});

Router.map(function() {
  this.route('user',{path:'user/:customerId'}, function() {
    this.route('profile',{path:'profile'});
    this.route('deposit',{path:'accounts/:accNo/deposit'});
    this.route('withdraw',{path:'accounts/:accNo/withdraw'});
    this.route('transfer',{path:'accounts/:accNo/transfer'});
  });
  this.route('login',{path:'/'});
  this.route('admin', function() {
    this.route('customer', function() {
      this.route('add');
      this.route('update',{path:'/:custId'});
      this.route('status',{path:'/:custId/change'});
    });
    this.route('account', function() {
      this.route('add');
      this.route('status',{path:'/:custId/:accNo/change'});
    });
    this.route('deposit');
    this.route('withdraw');
  });
});

export default Router;