import Ember from 'ember';

export default Ember.Component.extend({
    // service:Ember.inject.service('cust-details'),
    // logOutController:Ember.inject.controller('logout'),
    // init:
    // function removeAct()
    // {
    //     Ember.getOwner(this).lookup('controller:user').send('log_out')
    // },
    actions:
    {
        logout:function()
        {
            const d = new Date();
                        // d.setTime(d.getTime() + (0.01*24*60*60*1000));
                        let expires = "expires="+ d.toUTCString();
                        console.log(expires);
                        document.cookie = 'cname' + "=" + '' + ";" + expires + ";path=/"
            Ember.getOwner(this).lookup('controller:application').transitionToRoute('login');
        }
    }
});
