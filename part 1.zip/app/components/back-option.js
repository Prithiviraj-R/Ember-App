import Ember from 'ember';

export default Ember.Component.extend({
    actions:
    {
        back:function()
        {
            window.history.back();
            $('.options').css('color','white');
            $('.user_options').css('display','none');
            Ember.getOwner(this).lookup('controller:user').set('show',true);
            Ember.getOwner(this).lookup('controller:user').set('divClose',true);
        }
    }
});
