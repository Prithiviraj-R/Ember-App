import Ember from 'ember';

export default Ember.Route.extend({
    actions:
    {
        willTransition:function()
        {
            this.controller.set('amount','');
            this.controller.set('answer','');
        }
    },
    service:Ember.inject.service('cust-details'),
    beforeModel:function()
    {
        if(this.get('service').getName('userName')==null)
        {
            this.transitionTo('login');
        }
    },
    model:function(params)
    {
       // this.controllerFor('deposit').set('para', params.customerId);
    //    return {cusId:params.customerId,accNo:params.accNo};
    var parent_params=this.paramsFor('user');
    return {cusId:parent_params.customerId,accNo:params.accNo}
    }
});
