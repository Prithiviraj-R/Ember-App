import Ember from 'ember';

export default Ember.Route.extend({
    service:Ember.inject.service('cust-details'),
    beforeModel:function()
    {
        if(this.get('service').getName('userName')==null)
        {
            this.transitionTo('login');
        }
    },
    model:function(params)
    {
        var parent_params=this.paramsFor('user');
        return {cusId:parent_params.customerId,accNo:params.accNo};
    }
});
