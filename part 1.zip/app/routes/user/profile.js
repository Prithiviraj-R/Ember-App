import Ember from 'ember';

export default Ember.Route.extend({
    service:Ember.inject.service('cust-details'),
    beforeModel:function()
    {
        if(this.get('service').getName('userName')==null)
        {
            this.transitionTo('login');
        }
    },
    model : function()
    {
        // var id;
        // var details=this.controllerFor('user').get('model');
        // for(var i=0;i<details.length;i++)
        // {
        //     id=details[i].customerId
        //     break;
        // }
        var details=this.paramsFor('user');
        return Ember.$.get("http://localhost:8080/BankManagementWithAjax/user/"+details.customerId+"/profile",function(result)
       {
            console.log(result);
            return result;
        }).fail(function()
       {
           console.log("ERROR");
       })
    }
});
