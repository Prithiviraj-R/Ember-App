import Ember from 'ember';

export default Ember.Route.extend({
    service:Ember.inject.service('cust-details'),
    beforeModel:function()
    {
        if(this.get('service').getName('userName')==null)
        {
            this.transitionTo('login');
        }
    },
    
    model:function(params)
    {
        // function hello(name) {
        //     var match = document.cookie.split('=');
        //     for(var i=0;i<match.length;i++)
        //     {
        //         if(name==match[i])
        //         {
        //             return match[i+1]
        //         }
        //     }
        //   }
        //   var ji=hello('cname')
        //   console.log(ji);
        var _this=this;
        // this.set('userId',params.userId);
        // var userId=params.userId;
        // Ember.$.get("http://localhost:8080/BankManagementWithAjax/user/"+params.userId+"/profile",function(result)
        //         {
        //             console.log(result.customerName);
        //             controller.set('userDetails',result.customerName);
        //         }).fail(function()
        //         {
        //             console.log("ERROR");
        //         })
           
        
        // this.set('userId',userId)
        // return this.get('ajax').request('http://localhost:8080/BankManagementWithAjax/user/1/accounts/1/deposit',{
        //     method:'POST',
        //     data:{"accNo":"1","amount":"10"},
        //     success:function(result)
        //     {
        //         // return result;
        //         console.log("Jet");
        //         return $.parseJSON(result.sucess);
        //     },
        //     error:function()
        //     {
        //         console.log("I am HERE");
        //         return "ERROR";
        //     }
        // });
        //    return Ember.$.ajax(
        //         {
        //             url:"http://localhost:8080/BankManagementWithAjax/user/1/accounts/1/deposit",
        //             method:'POST',
        //             data:{"accNo":"1","amount":"10"},
        //             success:function(result)
        //                 {
        //                     return result;
        //                 },
        //             error:function()
        //                 {
        //                     console.log("I am HERE");
        //                     return "ERROR";
        //                 }
        //         }
        //     );
        // return Ember.$.post("http://localhost:8080/BankManagementWithAjax/user/1/accounts/1/deposit",{"accNo":"1","amount":"10"},function(result)
        // {
        //         console.log(result);
        //         return result.sucess;
        // }).fail(function()
        // {
        //     console.log("ERROR")
        // })
        //    return Ember.$.get("http://localhost:8080/BankManagementWithAjax/user/"+params.customerId,function(result)
        //    {
        //         return result;
        //    }).fail(function()
        //    {
        //        console.log("ERROR");
        //    })
       return Ember.$.ajax(
            {
                type:'GET',
                dataType:'json',
                xhrFields: {
                    withCredentials: true
                 },
                 crossdomain:true,
                url:"http://localhost:8080/BankManagementWithAjax/user/"+params.customerId,
                success:function(result)
                {
                    return result;
                },
                error:function(result)
                {
                    return result;
                }
            }
        );
    }
});