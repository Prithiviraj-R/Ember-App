import Ember from 'ember';

export default Ember.Route.extend({
    actions:
    {
        didTransition:function()
        {
            this.controller.set('userName','');
            this.controller.set('password','');
            this.controller.set('wrongAct','');
        }
    }
});
