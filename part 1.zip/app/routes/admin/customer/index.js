import Ember from 'ember';

export default Ember.Route.extend
({
    model:function()
    {
        return Ember.$.ajax(
            {
                type:'GET',
                url:'http://localhost:8080/BankManagementWithAjax/admin/customer',
                dataType:'json',
                success:function(result)
                {
                    return result;
                },
                error:function(result)
                {
                    return result
                }
            }
        )
    }
});
