import Ember from 'ember';

export default Ember.Route.extend({
    model:function(params)
    {
        var _this=this;
        var data=this.modelFor("admin.customer.index");
        console.log(data.length);
        for(var i=0;i<data.length;i++)
        {
            var arr=data[i];
            for(var j=0;j<arr.length;j++)
            {
                if(arr[j].CustId==params.custId)
                {
                    return {custDet:arr[j],custId:params.custId};
                }
            }
        }
    }
});
