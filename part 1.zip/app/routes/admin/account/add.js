import Ember from 'ember';

export default Ember.Route.extend({
    // model:function(params)
    // {
    //     return{customerId:params.custId,AccNum:accNo}
    // }
});
